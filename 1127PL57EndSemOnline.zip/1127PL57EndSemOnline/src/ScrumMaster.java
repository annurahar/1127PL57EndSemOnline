
public class ScrumMaster {
	private String name;

	public ScrumMaster(String name) {
		this.name = name;
	}
	
	public String toString()
	{
		return name;
	}
}
