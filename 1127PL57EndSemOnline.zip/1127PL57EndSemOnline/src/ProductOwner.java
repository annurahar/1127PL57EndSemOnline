
public class ProductOwner {
	private String name;

	public ProductOwner(String name) {
		this.name = name;
	}
	
	public String toString()
	{
		return name;
	}
}
